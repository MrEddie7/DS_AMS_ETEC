
package controle;

/**
 *
 * Classe de inicialização
 */
public class Principal {
    
    public static void main(String[] args) {
        new Frame();
    }
    
}
